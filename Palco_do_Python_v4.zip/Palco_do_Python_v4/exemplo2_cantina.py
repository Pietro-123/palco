import palco                                         # liga o Palco do Python
palco.npc("robo")                                    # o personagem vira um robô
palco.cenario("espaco")                              # a cena vai para o espaço

print("Bem-vindo à Cantina Espacial!")
preco = float(input("Quanto custa o lanche? "))      # float( ): número com ponto (ex.: 7.5)
pago = float(input("Quanto você vai pagar? "))
troco = round(pago - preco, 2)                       # a conta do troco, com 2 casas
print(f"Seu troco é {troco} reais.")
print("Volte sempre, terráqueo!")
