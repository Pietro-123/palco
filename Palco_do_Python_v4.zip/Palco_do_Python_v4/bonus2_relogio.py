import palco                                       # liga o palco
import datetime                                    # biblioteca de data e hora
agora = datetime.datetime.now()                    # data e hora de AGORA
if agora.hour < 12:                                # antes do meio-dia...
    print("Bom dia, aventureiro!")                 # ...bom dia
elif agora.hour < 18:                              # antes das 18h...
    print("Boa tarde, aventureiro!")               # ...boa tarde
else:                                              # depois das 18h...
    print("Boa noite, aventureiro!")               # ...boa noite
ano = int(input("Em que ano você nasceu?"))        # pergunta o ano
print(f"Este ano você faz {agora.year - ano}!")    # conta com o ano de hoje
