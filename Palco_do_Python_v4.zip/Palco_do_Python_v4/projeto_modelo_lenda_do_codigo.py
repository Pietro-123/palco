# ==================================================================
#  A LENDA DO CÓDIGO  ·  Projeto Final MODELO  ·  Ctrl Teens 2
#  Feito com o Palco do Python (o arquivo palco.py fica na mesma pasta)
#  Integrantes: ______________ / ______________ / ______________
# ==================================================================

import palco                                   # liga o palco: print vira fala e input vira pergunta
import random                                  # biblioteca do sorteio (números aleatórios)

# ---------------- MONTANDO O PALCO ----------------
palco.cenario("floresta")                      # a história começa na floresta
palco.npc("ogro")                              # o primeiro personagem é o ogro
palco.velocidade(1.2)                          # falas um pouco mais rápidas que o normal

# ---------------- VARIÁVEIS DO JOGO ----------------
vida = 10                                      # a vida do herói começa em 10
ouro = 0                                       # o herói começa sem nenhuma moeda
estrelas = 0                                   # estrelas ganhas nos desafios


def mostra_placar():                           # cria um comando novo chamado mostra_placar
    palco.placar(f"VIDA {vida}   OURO {ouro}   ESTRELAS {estrelas}")   # escreve o placar no canto da tela


mostra_placar()                                # mostra o placar pela primeira vez

# ==================================================================
#  CENA 1 · A FLORESTA                          feita por: __________
#  (input, .lower(), if/else, int e contas com + e *)
# ==================================================================
palco.narrar("Capítulo 1 · A Floresta Encantada")              # o narrador abre o capítulo
print("GRRR! Quem ousa entrar na MINHA floresta?")              # o ogro fala
nome = input("Qual é o seu nome, viajante?")                    # pergunta o nome e guarda na variável nome
tipo = input(f"{nome}, você é menino ou menina?").lower()       # .lower() deixa a resposta em minúsculas
if tipo == "menina":                           # se a resposta for menina...
    palco.heroi("menina")                      # ...o herói vira a menina
else:                                          # se for qualquer outra coisa...
    palco.heroi("menino")                      # ...fica o menino
idade = int(input("E quantos anos você tem?"))                 # int() transforma o texto em número inteiro
print(f"{idade} anos?! Eu tenho {idade * 20}. Sou 20 vezes mais velho!")   # conta de vezes (*)
print(f"Daqui a 10 anos você terá {idade + 10}... se passar da minha ponte! HA HA!")   # conta de mais (+)

# ==================================================================
#  CENA 2 · A PONTE DO OGRO                     feita por: __________
#  (desafio de conta, == e if/else, ganhar e perder pontos)
# ==================================================================
print("Para atravessar a minha ponte, responda:")              # o ogro lança o desafio
conta = int(input("Quanto é 7 x 8?"))                           # a resposta vira número
if conta == 56:                                # == compara: a resposta é igual a 56?
    ouro = ouro + 15                           # ganhou 15 moedas de ouro
    palco.festa()                              # chuva de confete!
    print("ACERTOU! Tome 15 moedas de ouro. Pode passar.")     # o ogro elogia
else:                                          # se errou...
    vida = vida - 3                            # ...perde 3 de vida
    palco.tremer()                             # a tela treme: levou um tapa!
    print("ERROU! Era 56. Toma um tapa: -3 de vida.")           # o ogro avisa
mostra_placar()                                # atualiza o placar

# ==================================================================
#  CENA 3 · O CASTELO DO MAGO                   feita por: __________
#  (troca de cenário, random, while, and/not, if/elif/else)
# ==================================================================
palco.cenario("castelo")                       # a cortina fecha e abre no castelo
palco.npc("mago")                              # o ogro vai embora e o mago chega
palco.narrar("Capítulo 2 · O Castelo do Mago")                 # novo capítulo
print(f"Bem-vindo, {nome}! Pensei num número mágico de 1 a 10.")   # o mago explica o desafio
secreto = random.randint(1, 10)                # sorteia o número secreto
tentativas = 3                                 # o herói tem 3 chances
acertou = False                                # ainda não acertou
while tentativas > 0 and not acertou:          # repete enquanto tiver chance E ainda não acertou
    chute = int(input(f"Qual é o número? Chances: {tentativas}"))    # pede um chute
    tentativas = tentativas - 1                # gastou uma chance
    if chute == secreto:                       # se acertou...
        acertou = True                         # ...marca que acertou (o while para)
    elif chute < secreto:                      # se o chute foi menor...
        print("É mais ALTO!")                  # ...dica para subir
    else:                                      # se o chute foi maior...
        print("É mais BAIXO!")                 # ...dica para descer
if acertou:                                    # depois do while: acertou?
    estrelas = estrelas + 2                    # ganha 2 estrelas
    palco.festa()                              # confete!
    print(f"MÁGICO! Era {secreto} mesmo. +2 estrelas!")         # o mago comemora
else:                                          # se as chances acabaram...
    print(f"Suas chances acabaram... era o {secreto}.")         # o mago revela o número
mostra_placar()                                # atualiza o placar

# ==================================================================
#  CENA 4 · A LOJA DE POÇÕES                    feita por: __________
#  (contas com *, -, // e %)
# ==================================================================
print("Antes do dragão, compre poções! Cada uma custa 7 moedas e cura 2 de vida.")   # o mago vende
quantas = int(input(f"Você tem {ouro} moedas. Quantas poções quer?"))   # pergunta a quantidade
preco = quantas * 7                            # preço total = quantidade x 7
if preco <= ouro:                              # se o ouro dá para pagar...
    ouro = ouro - preco                        # ...paga as poções
    vida = vida + quantas * 2                  # cada poção cura 2 de vida
    print(f"Pronto! {quantas} poções por {preco} moedas. +{quantas * 2} de vida!")   # confirma a compra
else:                                          # se o ouro não dá...
    print(f"Não dá! Com {ouro} moedas você compra {ouro // 7} e sobram {ouro % 7}.")   # // divisão inteira, % resto
mostra_placar()                                # atualiza o placar

# ==================================================================
#  CENA 5 · A BATALHA CONTRA O DRAGÃO           feita por: __________
#  (while de batalha, random, .lower(), if/elif/else, //)
# ==================================================================
palco.npc("dragao")                            # o mago some e o DRAGÃO aparece
palco.narrar("Capítulo 3 · O Dragão do Castelo")               # novo capítulo
palco.tremer()                                 # o chão treme com o rugido
print("ROOOAR! Ninguém passa do meu castelo!")  # o dragão ruge
vida_dragao = 15                               # a vida do dragão
while vida_dragao > 0 and vida > 0:            # a luta continua enquanto os DOIS estiverem de pé
    defendeu = False                           # no começo da rodada o escudo está abaixado
    acao = input("ATACAR ou DEFENDER?").lower()                 # o herói escolhe a ação
    if acao == "atacar":                       # se escolheu atacar...
        dano = random.randint(3, 6) + estrelas  # dano sorteado + bônus das estrelas
        vida_dragao = vida_dragao - dano       # o dragão perde vida
        if vida_dragao < 0:                    # para não mostrar vida negativa...
            vida_dragao = 0                    # ...trava no zero
        print(f"POW! {dano} de dano. Vida do dragão: {vida_dragao}")   # mostra o golpe
    elif acao == "defender":                   # se escolheu defender...
        defendeu = True                        # ...levanta o escudo
        print("Você levantou o escudo mágico!")  # avisa
    else:                                      # se digitou outra coisa...
        print("Isso não é um golpe! Perdeu a vez.")             # perdeu a vez
    if vida_dragao > 0:                        # se o dragão ainda está vivo, ele ataca
        fogo = random.randint(2, 5)            # sorteia a força do fogo
        if defendeu:                           # se o herói defendeu...
            fogo = fogo // 2                   # ...o escudo corta o fogo pela metade
        vida = vida - fogo                     # o herói perde vida
        if vida < 0:                           # para não mostrar vida negativa...
            vida = 0                           # ...trava no zero
        palco.tremer()                         # a tela treme
        print(f"O dragão cuspiu fogo! -{fogo} de vida.")        # avisa o dano
    mostra_placar()                            # atualiza o placar a cada rodada
if vida > 0:                                   # saiu do while com vida: VENCEU!
    ouro = ouro + 30                           # tesouro do dragão
    estrelas = estrelas + 3                    # +3 estrelas
    palco.festa()                              # festa!
    print("O dragão foi DERROTADO! Tesouro: +30 de ouro e +3 estrelas!")   # comemora
else:                                          # saiu do while sem vida: perdeu...
    vida = 1                                   # ...mas é salvo com 1 de vida
    print("Você caiu... mas uma luz azul te puxou para o céu!")   # gancho para a próxima cena
mostra_placar()                                # atualiza o placar

# ==================================================================
#  CENA 6 · A ESTAÇÃO ESPACIAL (FINAL)          feita por: __________
#  (float, round, .upper(), or, **, if/elif/else e resultado final)
# ==================================================================
palco.cenario("espaco")                        # a cortina leva o herói para o espaço
palco.npc("robo")                              # o robô assume a cena
palco.narrar("Capítulo 4 · A Estação Espacial")                # último capítulo
print(f"BIP BOP! Agente {nome.upper()}, bem-vindo à Lua!")     # .upper() deixa o nome em MAIÚSCULAS
pulo = float(input("Quantos metros você pula na Terra? (ex: 0.5)"))   # float aceita número com ponto
print(f"Na Lua a gravidade é 6x menor: você pularia {round(pulo * 6, 1)} metros!")   # round arredonda
resposta = input("Última pergunta: o Python diferencia maiúscula de minúscula? (sim/não)").lower()   # pergunta final
if resposta == "sim" or resposta == "s":       # aceita "sim" OU "s"
    estrelas = estrelas + 1                    # +1 estrela
    print("CORRETO! nome e Nome são variáveis diferentes.")     # explica
else:                                          # qualquer outra resposta...
    print("Diferencia sim! nome e Nome são variáveis diferentes.")   # corrige
bonus = estrelas ** 2                          # ** é potência: estrelas ao quadrado
pontos = ouro + vida * 5 + bonus               # fórmula da pontuação final
print(f"Calculando: {ouro} de ouro + {vida * 5} da vida + {bonus} de bônus = {pontos} pontos!")   # mostra a conta
if pontos >= 90:                               # 90 pontos ou mais...
    titulo = "LENDA DO CÓDIGO"                 # ...título máximo
elif pontos >= 50:                             # de 50 a 89...
    titulo = "HERÓI PROGRAMADOR"               # ...título do meio
else:                                          # menos de 50...
    titulo = "APRENDIZ CORAJOSO"               # ...título de quem está começando
palco.placar(f"{nome.upper()}  ·  {pontos} PONTOS  ·  {titulo}")   # placar final
palco.festa()                                  # festa final
palco.narrar(f"{nome}, você é: {titulo}!")     # o narrador anuncia o título
print("Obrigado por jogar! Um jogo de: (nomes da dupla ou do trio)")   # créditos finais
