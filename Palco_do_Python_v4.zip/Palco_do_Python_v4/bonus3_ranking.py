import palco                                       # liga o palco
nome = input("Qual é o seu nome?")                 # nome do jogador
pontos = 85                                        # no jogo, vem da história
arquivo = open("ranking.txt", "a")                 # "a" = acrescentar no fim
arquivo.write(f"{nome}: {pontos} pontos\n")        # escreve uma linha nova
arquivo.close()                                    # fecha e salva
arquivo = open("ranking.txt", "r")                 # "r" = ler
print("HALL DA FAMA:")                             # título
print(arquivo.read())                              # lê o arquivo inteiro
arquivo.close()                                    # fecha
