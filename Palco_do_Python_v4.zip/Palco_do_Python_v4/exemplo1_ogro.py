import palco                                         # liga o Palco do Python (SEMPRE a 1ª linha)

print("GRRR! Quem entrou na minha floresta?")        # o ogro fala
nome = input("Qual é o seu nome, humano? ")          # o ogro pergunta; a resposta vai para a caixa nome
print(f"Hmm... {nome}. Nome estranho!")              # f-string: o {nome} vira o que você digitou
idade = int(input("Quantos anos você tem? "))        # int( ) transforma a resposta em número
print(f"Daqui a 10 anos você vai ter {idade + 10} anos.")   # conta com o número
comida = input("Qual é a sua comida favorita? ")     # mais uma pergunta
print(f"{comida}?! Eu também amo {comida}! Pode passar, {nome}.")
