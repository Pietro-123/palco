import palco                                         # liga o Palco do Python
palco.npc("dragao")                                  # o personagem vira um dragão
palco.cenario("castelo")                             # cenário do castelo
palco.heroi("menina")                                # a heroína

print("Eu sou o dragão guardião do tesouro!")
moedas = int(input("Quantas moedas de ouro você quer? "))
amigos = int(input("Quantos amigos vão dividir? "))
cada = moedas // amigos                              # // divisão inteira: quanto cada um leva
sobra = moedas % amigos                              # % resto: o que sobra
print(f"Cada amigo leva {cada} moedas.")
print(f"Sobram {sobra} moedas... que ficam comigo! HAHAHA")
