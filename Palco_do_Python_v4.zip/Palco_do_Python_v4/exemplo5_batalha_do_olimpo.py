import palco                                              # liga o palco (versão 3 · RPG)
import random                                             # biblioteca do sorteio

# ---------------- CENA 1 · A VILA ----------------
palco.cenario("vila")                                     # a história começa na vila
palco.npc("sabio")                                        # o sábio conversa com você
nome = input("Bem-vindo, aventureiro! Qual é o seu nome?")   # pergunta o nome
palco.nome_heroi(nome)                                    # o seu nome aparece embaixo do herói
classe = input("Você é guerreira, mago ou arqueiro?").lower()   # escolhe a classe
if classe == "guerreira":                                 # se escolheu guerreira...
    palco.heroi("guerreira")                              # ...vira a guerreira
    palco.arma("espada")                                  # ...e segura a espada
elif classe == "mago":                                    # se escolheu mago...
    palco.heroi("mago")                                   # ...vira o mago
    palco.arma("varinha")                                 # ...e segura a varinha
else:                                                     # qualquer outra resposta...
    palco.heroi("arqueiro")                               # ...vira o arqueiro
    palco.arma("arco")                                    # ...e segura o arco
print(f"{nome}, Zeus precisa de você! Leve esta poção.")  # o sábio fala
palco.item("pocao")                                       # você ganha a poção (vai para a BOLSA)

# ---------------- CENA 2 · O MONTE OLIMPO ----------------
palco.cenario("olimpo")                                   # a cortina leva você ao Olimpo
palco.npc("hades")                                        # o sábio sai e Hades chega
palco.narrar("Capítulo 2 · O Ataque de Hades")            # o narrador anuncia
vida = 10                                                 # a sua vida
vida_hades = 15                                           # a vida de Hades
palco.vida_heroi(vida)                                    # barra de vida embaixo de você
palco.vida_npc(vida_hades)                                # barra de vida embaixo de Hades
print("HAHAHA! O Olimpo agora é MEU!")                    # Hades provoca

while vida > 0 and vida_hades > 0:                        # a batalha continua enquanto os dois estão de pé
    golpe = input("Escolha seu poder: fogo, gelo ou raio").lower()   # você escolhe o poder
    if golpe == "gelo":                                   # se escolheu gelo...
        palco.poder("gelo")                               # ...lança o gelo
        palco.status("congelado")                         # ...e Hades fica congelado
    elif golpe == "raio":                                 # se escolheu raio...
        palco.poder("raio")                               # ...cai um raio em Hades
    else:                                                 # qualquer outra resposta...
        palco.poder("fogo")                               # ...bola de fogo!
    dano = random.randint(3, 6)                           # sorteia o dano do seu golpe
    vida_hades = vida_hades - dano                        # Hades perde vida
    palco.dano(dano)                                      # mostra o -dano em Hades
    palco.vida_npc(vida_hades)                            # atualiza a barra de Hades
    if vida_hades > 0:                                    # se Hades ainda está de pé, ele ataca
        palco.status("normal")                            # sai do gelo
        palco.poder("sombra", "npc")                      # Hades lança a sombra em você
        vida = vida - 3                                   # você perde 3 de vida
        palco.dano(3, "heroi")                            # mostra o -3 em você
        palco.vida_heroi(vida)                            # atualiza a sua barra
        if vida <= 4 and palco.tem("pocao"):              # vida baixa E tem poção na bolsa?
            palco.usar("pocao")                           # usa a poção
            vida = vida + 5                               # recupera 5 de vida
            palco.cura(5)                                 # mostra o +5 em você
            palco.vida_heroi(vida)                        # atualiza a sua barra

# ---------------- CENA 3 · O FINAL ----------------
if vida > 0:                                              # você venceu!
    palco.efeito("sumir")                                 # Hades some numa nuvem de fumaça
    palco.npc("zeus")                                     # Zeus chega
    print(f"Obrigado, {nome}! O Olimpo está salvo!")      # Zeus agradece
    palco.efeito("level up")                              # LEVEL UP!
    palco.efeito("moedas")                                # chuva de moedas
else:                                                     # você perdeu...
    palco.efeito("noite")                                 # o céu escurece
    print("O Olimpo caiu... mas todo herói tenta de novo!")   # Hades comemora
