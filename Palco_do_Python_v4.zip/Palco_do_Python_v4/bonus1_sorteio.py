import palco                                       # liga o palco
import random                                      # biblioteca do sorteio
palco.npc("robo")                                  # o robô apresenta
inimigos = ["um lobo", "um goblin", "um fantasma"] # lista de inimigos
inimigo = random.choice(inimigos)                  # sorteia UM da lista
print(f"ALERTA! Apareceu {inimigo}!")              # cada partida é diferente
gritos = ["Hahaha!", "Grrr!", "Você não passa!"]   # lista de falas
print(random.choice(gritos))                       # fala sorteada
