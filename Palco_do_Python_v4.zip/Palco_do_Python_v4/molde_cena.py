import palco                              # liga o palco
palco.cenario("castelo")                  # escolhe o cenário
palco.npc("mago")                         # escolhe o personagem
palco.narrar("Capítulo 1 · O Desafio")    # o narrador abre o capítulo
nome = input("Qual é o seu nome?")        # pergunta e guarda a resposta
print(f"Bem-vindo, {nome}!")              # o personagem usa a resposta
conta = int(input("Quanto é 3 x 4?"))     # um desafio com número
if conta == 12:                           # se acertou...
    palco.festa()                         # ...confete!
    print("Acertou! Pode passar.")        # ...e comemora
else:                                     # se errou...
    palco.tremer()                        # ...a tela treme
    print("Errou! Era 12.")               # ...e corrige
