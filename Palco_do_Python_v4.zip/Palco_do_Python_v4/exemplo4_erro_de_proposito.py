import palco                                         # liga o Palco do Python

nome = input("Qual é o seu nome? ")                  # texto: qualquer coisa serve
idade = int(input("Quantos anos você tem? "))        # TESTE: digite "doze" (com letras) e veja o ogro avisar do erro
print(f"{nome} tem {idade} anos.")                   # com número (12) dá certo
