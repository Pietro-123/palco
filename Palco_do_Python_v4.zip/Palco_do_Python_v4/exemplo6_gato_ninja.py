import palco                                                     # liga o palco (versão 4)
import random                                                    # biblioteca do sorteio

# ---------------- ABERTURA ----------------
palco.titulo("O Gato Ninja", "e a Noite dos Zumbis")             # tela de título na cortina
palco.som(True)                                                  # liga os sons (só no Windows)
palco.musica("aventura")                                         # música de aventura
palco.cenario("cidade_noturna.png")                              # o FUNDO foi desenhado no Piskel
palco.heroi("gato_ninja.png")                                    # o HERÓI foi desenhado no Piskel
palco.npc("guarda")                                              # o guarda da cidade conversa com você
nome = input("Alto lá! Quem anda pela rua a esta hora?")         # o guarda pergunta o seu nome
palco.nome_heroi(nome)                                           # o seu nome aparece embaixo do gato
palco.diz("Sou um gato ninja. Ouvi gritos lá no cemitério!")     # o HERÓI fala (sem pergunta)
palco.emocao("nervoso")                                          # o guarda fica nervoso (gota de suor)
print("Os zumbis saíram das covas! Ajude a cidade!")             # o guarda pede ajuda
palco.emocao("!", "heroi")                                       # o gato leva um susto

# ---------------- CENA 2 · O CEMITÉRIO ----------------
palco.titulo("Capítulo 1", "O Cemitério")                        # cartão de capítulo na cortina
palco.cenario("cemiterio")                                       # agora a cena é no cemitério
palco.efeito("noite")                                            # o céu escurece
palco.musica("misterio")                                         # música de suspense
palco.npc("zumbi")                                               # o zumbi chega
palco.entra("esqueleto")                                         # o esqueleto entra ao lado dele
palco.diz("GRRRR... cérebrooo...", "zumbi")                      # o zumbi fala
palco.entra("fada", "heroi")                                     # uma fada entra do SEU lado
palco.diz("Calma, gatinho! Eu vou ajudar!", "fada")              # a fada fala
vida = 12                                                        # a sua vida
horda = 10                                                       # a vida da horda de mortos-vivos
palco.vida_heroi(vida)                                           # barra de vida embaixo de você
palco.vida_npc(horda)                                            # barra de vida embaixo do zumbi
palco.musica("batalha")                                          # música de batalha

while horda > 0 and vida > 0:                                    # a luta continua enquanto os dois estão de pé
    acao = palco.escolha("Ataque ninja", "Estrela de fogo", "Luz da fada")   # 3 botões para clicar
    if acao == "Ataque ninja":                                   # se clicou no botão 1...
        palco.ataque()                                           # ...o gato corre e golpeia
        golpe = random.randint(2, 4)                             # ...dano de 2 a 4
    elif acao == "Estrela de fogo":                              # se clicou no botão 2...
        palco.poder("fogo")                                      # ...bola de fogo
        golpe = random.randint(1, 5)                             # ...dano de 1 a 5
    else:                                                        # se clicou no botão 3...
        palco.poder("luz", "fada", "zumbi")                      # ...a FADA lança luz no zumbi
        golpe = 3                                                # ...dano fixo de 3
    horda = horda - golpe                                        # a horda perde vida
    palco.dano(golpe)                                            # mostra o -golpe no zumbi
    palco.vida_npc(horda)                                        # atualiza a barra do zumbi
    if horda > 0:                                                # se a horda ainda está de pé...
        palco.emocao("raiva", "esqueleto")                       # ...o esqueleto fica com raiva
        palco.ataque("esqueleto")                                # ...e ataca você
        vida = vida - 2                                          # você perde 2 de vida
        palco.dano(2, "heroi")                                   # mostra o -2 em você
        palco.vida_heroi(vida)                                   # atualiza a sua barra

# ---------------- CENA 3 · O FINAL ----------------
if vida > 0:                                                     # você venceu a horda!
    palco.efeito("sumir", "esqueleto")                           # o esqueleto vira fumaça
    palco.sai("esqueleto")                                       # e sai de cena
    palco.efeito("sumir")                                        # o zumbi também some
    palco.pular()                                                # o gato pula de alegria
    palco.efeito("level up")                                     # LEVEL UP!
    palco.npc("necromante")                                      # o chefe chega
    palco.emocao("raiva")                                        # o necromante fica bravo
    conta = int(input("Responda ou vire zumbi: quanto é 13 + 29?"))   # int() transforma a resposta em número
    if conta == 42:                                              # acertou a conta?
        palco.status("petrificado")                              # o necromante vira pedra
        palco.emocao("feliz", "heroi")                           # o gato fica feliz
        palco.musica("vitoria")                                  # música de vitória
        print(f"Nãããão! {nome} me venceu com a matemática!")     # o necromante perde
        palco.efeito("moedas")                                   # chuva de moedas
    else:                                                        # errou a conta...
        palco.poder("sombra", "npc")                             # o necromante lança a sombra
        print(f"HAHAHA! Errou, {nome}! A resposta era 42!")       # e ri de você
else:                                                            # a sua vida acabou...
    palco.emocao("triste", "heroi")                              # o gato fica triste
    print("Os zumbis venceram... mas todo ninja tenta de novo!")  # o zumbi comemora

palco.creditos(f"Herói: {nome}", "Arte: desenhada no Piskel", "Um projeto Ctrl Teens 2")   # créditos no final
